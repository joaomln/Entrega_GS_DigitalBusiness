package br.com.fiap.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Setup {
	
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name = "Nome";
	private LocalDate dt_nasc = LocalDate.of(2000, 02, 01);
	private long CPF = 11122233304L;
	private Integer RG = 555666777;
	private byte dg_RG = 8;
	private LocalDate dt_cad = LocalDate.now();
	private String imagePath;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDt_nasc() {
		return dt_nasc;
	}
	public void setDt_nasc(LocalDate dt_nasc) {
		this.dt_nasc = dt_nasc;
	}
	public long getCPF() {
		return CPF;
	}
	public void setCPF(long cPF) {
		CPF = cPF;
	}
	public Integer getRG() {
		return RG;
	}
	public void setRG(Integer rG) {
		RG = rG;
	}
	public byte getDg_RG() {
		return dg_RG;
	}
	public void setDg_RG(byte dg_RG) {
		this.dg_RG = dg_RG;
	}
	public LocalDate getDt_cad() {
		return dt_cad;
	}
	public void setDt_cad(LocalDate dt_cad) {
		this.dt_cad = dt_cad;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	@Override
	public String toString() {
		return "Setup [id=" + id + ", name=" + name + ", dt_nasc=" + dt_nasc + ", CPF=" + CPF + ", RG=" + RG
				+ ", dg_RG=" + dg_RG + ", dt_cad=" + dt_cad + ", imagePath=" + imagePath + "]";
	}
	
	
	
	
	

}
